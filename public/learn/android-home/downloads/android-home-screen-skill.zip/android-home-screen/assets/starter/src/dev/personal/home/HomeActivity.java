package dev.personal.home;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class HomeActivity extends Activity {
    private static final int PAPER=0xfff3eee5,INK=0xff242726,RED=0xffac3428;
    private FrameLayout root;
    private LinearLayout home,capture;
    private TextView clock;
    private EditText note;
    private boolean showingCapture=false;
    private Dialog drawer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));handler.postDelayed(this,1000);}};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(PAPER);getWindow().setNavigationBarColor(PAPER);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=new FrameLayout(this){float x,y;boolean swipe;
            @Override public void requestDisallowInterceptTouchEvent(boolean disallow){super.requestDisallowInterceptTouchEvent(showingCapture?disallow:false);}
            @Override public boolean onInterceptTouchEvent(MotionEvent e){int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN){x=e.getX();y=e.getY();swipe=false;}if(action==MotionEvent.ACTION_POINTER_DOWN||action==MotionEvent.ACTION_CANCEL){y=-100000;swipe=false;}if(!showingCapture&&action==MotionEvent.ACTION_MOVE&&e.getY()-y < -dp(64)&&y-e.getY()>Math.abs(e.getX()-x)*1.4){swipe=true;return true;}return false;}
            @Override public boolean onTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_UP&&swipe){swipe=false;showApps();}if(e.getActionMasked()==MotionEvent.ACTION_CANCEL)swipe=false;return true;}
        };
        root.setBackgroundColor(PAPER);home=column();home.setPadding(dp(24),dp(28),dp(24),dp(20));clock=text("",68,INK);clock.setTypeface(Typeface.DEFAULT_BOLD);home.addView(clock);home.addView(text("YOUR PHONE. YOUR WAY.",12,RED));space(home,32);
        TextView headline=text("Make room for\nwhat matters.",34,INK);headline.setTypeface(Typeface.DEFAULT_BOLD);home.addView(headline);space(home,24);
        home.addView(button("Capture a thought",()->showCapture()),new LinearLayout.LayoutParams(-1,dp(60)));space(home,12);
        home.addView(button("All apps",()->showApps()),new LinearLayout.LayoutParams(-1,dp(60)));space(home,12);
        home.addView(button("Choose Home app",()->startActivity(new Intent(Settings.ACTION_HOME_SETTINGS))),new LinearLayout.LayoutParams(-1,dp(60)));space(home,16);
        home.addView(text("Swipe up for your apps.\nYour original launcher stays available in Home app settings.",13,INK));
        capture=column();capture.setPadding(dp(24),dp(20),dp(24),dp(20));capture.addView(text("CAPTURE",28,INK));space(capture,18);note=new EditText(this);note.setGravity(Gravity.TOP);note.setHint("A useful idea, a note, a next step…");note.setTextColor(INK);capture.addView(note,new LinearLayout.LayoutParams(-1,0,1));
        capture.addView(button("Save on this phone",()->{saveNote();Toast.makeText(this,"Saved on this phone",Toast.LENGTH_SHORT).show();showHome();}),new LinearLayout.LayoutParams(-1,dp(56)));capture.addView(button("Back home",()->showHome()),new LinearLayout.LayoutParams(-1,dp(56)));
        root.addView(home,new FrameLayout.LayoutParams(-1,-1));root.addView(capture,new FrameLayout.LayoutParams(-1,-1));capture.setVisibility(View.GONE);setContentView(root);
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::showHome);
    }
    @Override public void onResume(){super.onResume();handler.removeCallbacks(tick);handler.post(tick);}
    @Override public void onPause(){saveNote();handler.removeCallbacks(tick);super.onPause();}
    @Override public void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
    @Override public void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(drawer!=null)drawer.dismiss();showHome();}
    @Override public void onBackPressed(){showHome();}
    private void saveNote(){if(showingCapture&&note!=null)getSharedPreferences("notes",MODE_PRIVATE).edit().putString("note",note.getText().toString()).apply();}
    private void showCapture(){showingCapture=true;note.setText(getSharedPreferences("notes",MODE_PRIVATE).getString("note",""));home.setVisibility(View.INVISIBLE);capture.setVisibility(View.VISIBLE);}
    private void showHome(){saveNote();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(note.getWindowToken(),0);showingCapture=false;capture.setVisibility(View.GONE);home.setVisibility(View.VISIBLE);}
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout column(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);return view;}
    private TextView text(String value,int size,int color){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(color);return view;}
    private void space(LinearLayout parent,int height){parent.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
    private Button button(String title,Runnable action){Button button=new Button(this);button.setText(title);button.setTextColor(INK);button.setAllCaps(false);button.setOnClickListener(v->action.run());return button;}
    private void showApps(){
        if(drawer!=null&&drawer.isShowing())return;
        ArrayList<ResolveInfo> apps=new ArrayList<>(getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0));apps.removeIf(a->a.activityInfo.packageName.equals(getPackageName()));apps.sort((a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        ArrayList<String> labels=new ArrayList<>();for(ResolveInfo app:apps)labels.add(app.loadLabel(getPackageManager()).toString());
        ListView list=new ListView(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,labels);list.setAdapter(adapter);
        LinearLayout body=column();body.setPadding(dp(20),dp(24),dp(20),dp(16));body.setBackgroundColor(PAPER);body.addView(button("Close apps",()->drawer.dismiss()),new LinearLayout.LayoutParams(-1,dp(52)));body.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout frame=new FrameLayout(this){float x,y;boolean atTop,swipe;
            @Override public void requestDisallowInterceptTouchEvent(boolean value){super.requestDisallowInterceptTouchEvent(atTop?false:value);}
            @Override public boolean onInterceptTouchEvent(MotionEvent e){int a=e.getActionMasked();if(a==MotionEvent.ACTION_DOWN){x=e.getX();y=e.getY();atTop=!list.canScrollVertically(-1);swipe=false;}if(a==MotionEvent.ACTION_CANCEL||a==MotionEvent.ACTION_POINTER_DOWN){atTop=false;swipe=false;}if(atTop&&a==MotionEvent.ACTION_MOVE&&e.getY()-y>dp(64)&&e.getY()-y>Math.abs(e.getX()-x)*1.4){swipe=true;return true;}return false;}
            @Override public boolean onTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_UP&&swipe){swipe=false;drawer.dismiss();showHome();}if(e.getActionMasked()==MotionEvent.ACTION_CANCEL)swipe=false;return true;}
        };
        frame.addView(body,new FrameLayout.LayoutParams(-1,-1));drawer=new Dialog(this,android.R.style.Theme_Material_Light_NoActionBar);drawer.setContentView(frame);drawer.show();drawer.getWindow().setLayout(-1,-1);
        list.setOnItemClickListener((parent,view,pos,item)->{ActivityInfo app=apps.get(pos).activityInfo;Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(app.packageName,app.name));try{startActivity(intent);drawer.dismiss();}catch(ActivityNotFoundException error){Toast.makeText(this,"This app could not open",Toast.LENGTH_SHORT).show();}});
    }
}
