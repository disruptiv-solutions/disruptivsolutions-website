"""Build with an existing Android SDK and JDK; no downloads or device changes."""
from pathlib import Path
import argparse
import os
import re
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sdk', help='Android SDK root (or ANDROID_HOME / ANDROID_SDK_ROOT)')
parser.add_argument('--tools', help='Exact build-tools folder containing aapt2, d8 and zipalign')
parser.add_argument('--android-jar', help='Exact platform android.jar')
args = parser.parse_args()
sdk_value = args.sdk or os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
if not sdk_value and not (args.tools and args.android_jar):
    parser.error('Set ANDROID_HOME, or supply --sdk, or supply --tools and --android-jar.')
sdk = Path(sdk_value).resolve() if sdk_value else None
def newest(folder, required):
    choices = [p for p in folder.iterdir() if p.is_dir() and (p / required).is_file()] if folder.exists() else []
    if not choices:
        raise SystemExit(f'No installed Android tools/platform found in {folder}. Ask your agent to set up the SDK.')
    return max(choices, key=lambda p: tuple(int(n) for n in re.findall(r'\d+', p.name)))
suffix = '.exe' if os.name == 'nt' else ''
tools = Path(args.tools).resolve() if args.tools else newest(sdk / 'build-tools', 'aapt2' + suffix)
android = Path(args.android_jar).resolve() if args.android_jar else newest(sdk / 'platforms', 'android.jar') / 'android.jar'
java = {name: shutil.which(name) for name in ['java', 'javac', 'keytool']}
if not all(java.values()):
    raise SystemExit('A JDK with java, javac and keytool must be on PATH.')
for required in [tools / ('aapt2' + suffix), tools / ('zipalign' + suffix), tools / 'lib/d8.jar', tools / 'lib/apksigner.jar', android]:
    if not required.is_file():
        raise SystemExit(f'Missing installed tool: {required}')
local = root / '.local'
classes, dex = local / 'classes', local / 'dex'
classes.mkdir(parents=True, exist_ok=True)
dex.mkdir(parents=True, exist_ok=True)
def run(*command):
    subprocess.run([str(part) for part in command], cwd=root, check=True)
run(tools / ('aapt2' + suffix), 'compile', '--dir', root / 'res', '-o', local / 'resources.zip')
run(tools / ('aapt2' + suffix), 'link', '-o', local / 'base.apk', '--manifest', root / 'AndroidManifest.xml', '-I', android, '--min-sdk-version', '30', '--target-sdk-version', '36', local / 'resources.zip')
sources = list((root / 'src').rglob('*.java'))
run(java['javac'], '-encoding', 'UTF-8', '-source', '8', '-target', '8', '-bootclasspath', os.pathsep.join([str(tools / 'core-lambda-stubs.jar'), str(android)]), '-d', classes, *sources)
run(java['java'], '-Xmx512m', '-cp', tools / 'lib/d8.jar', 'com.android.tools.r8.D8', '--min-api', '30', '--lib', android, '--output', dex, *classes.rglob('*.class'))
with zipfile.ZipFile(local / 'base.apk', 'a') as archive:
    for file in dex.glob('*.dex'):
        archive.write(file, file.name)
run(tools / ('zipalign' + suffix), '-f', '-p', '4', local / 'base.apk', local / 'aligned.apk')
key = local / 'debug.keystore'
if not key.exists():
    run(java['keytool'], '-genkeypair', '-keystore', key, '-storepass', 'android', '-keypass', 'android', '-alias', 'my-home', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '3650', '-dname', 'CN=Personal Home Debug', '-noprompt')
apk = local / 'MyHome.apk'
run(java['java'], '-jar', tools / 'lib/apksigner.jar', 'sign', '--ks', key, '--ks-key-alias', 'my-home', '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', apk, local / 'aligned.apk')
run(java['java'], '-jar', tools / 'lib/apksigner.jar', 'verify', apk)
print(f'Built and signature-checked: {apk}\nNo phone installation or default-home change was performed.')
