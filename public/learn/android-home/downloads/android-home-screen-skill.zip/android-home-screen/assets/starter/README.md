# My Home — small native Android starter

This source starter supplies a clock, installed-app shortcuts and drawer, persistent text notes, a swipe up to the drawer and a downward swipe at its top to close. It has no online service, API key or audio-file recorder. Use the keyboard’s dictation if available, or ask your agent to add voice recording as a separate step.

Requirements: Android 11+, Python 3.9+, a JDK with `java`, `javac` and `keytool` on PATH, and installed Android SDK platform and build tools. `ANDROID_HOME` or `ANDROID_SDK_ROOT` can locate a standard SDK. Build with `python build.py`; run `python build.py --help` for exact tool paths. No Gradle or Python package installation is required.

The build creates `.local/MyHome.apk` and a private local debug signing key. Keep that key to update the same app. Do not include `.local/` in shared source. The distributed kit contains no signing key or APK.

Have your coding agent verify the exact device before installing. Open the app and check the controls first. The “Choose Home app” button opens Android settings; you choose the default yourself. You can return to the original launcher in the same setting.

The lesson’s build receipt records compilation. Physical-device behaviour still needs testing on your phone. A working starter is the beginning of your own design, rather than a copy of Ian’s private AgentOps setup.
