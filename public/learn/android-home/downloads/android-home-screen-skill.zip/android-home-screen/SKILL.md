---
name: android-home-screen
description: Build and refine a personal Android home launcher with real app shortcuts and local capture, then install and verify it on the owner’s chosen phone. Use for a custom Android home screen, not for iPhone customization or ordinary wallpaper changes.
---

# Build a personal Android home screen

Start with one useful screen: a clock, a few real shortcuts and local text capture. Use the learner’s colours, name and actual installed apps. Add voice recording or online actions only when requested and the basic launcher works.

## Establish the environment

Read the project instructions and inspect the available tools. This needs a coding agent with local file/terminal access, an Android 11+ device for the bundled starter, Android SDK platform/build tools, Java and an authorized connection to that specific phone. A skill file does not supply those tools or credentials.

Ask only for consequential missing inputs: the target phone if ambiguous, a preferred visual reference and the few daily actions. Reuse installed SDKs and existing project/signing keys. Show a small browser or native preview before replacing a home workflow.

Use an available mobile-control harness for UI interaction. Use ADB for device inventory, pairing, installation and diagnostics. Show the observed model and serial to identify the selected phone; every install targets that exact device. USB tethering alone is not debugging authorization. For wireless debugging the pairing port/code and the connection port are separate. When the connection fails, ask for current details rather than repeatedly guessing ports or resetting keys.

## Build the smallest working version

Copy [assets/starter](assets/starter) into a new project. Read its README. `build.py` uses the standard library and existing Android tools; it does not install an SDK. Change the package identifier when the learner needs a distinct app. Keep local signing material private and reuse it for updates.

Prefer native controls for phone actions and capture. For a bundled HTML design, keep the bridge small, whitelist actions and serve only trusted local assets. Never place service keys in HTML or the APK. Match the window background to the design, keep the home view alive across page changes, and pause offscreen motion without resetting its position.

Keep the existing home app and personal data available. Update this app in place with its original signing key; uninstalling it erases its local notes. Never uninstall another launcher or clear its data as a shortcut. Do not force a default-home change. After the learner chooses to make this the default, open Android’s Home app setting so they make that choice themselves.

## Verify and refine

Use the [device checkpoints](references/checkpoints.md). A successful build is not a successful installation, and a browser prototype is not a physical phone test. Report separately: preview verified, build verified, installed, default home selected and device behaviour checked.

For an online button, use the owner’s real service and supported API with server-side credentials and bounded actions. Distinguish read, save, draft and execute. AI category suggestions should remain suggestions until the owner files them. Do not activate agents, send messages or mark work complete merely because a capture mentions an action.

Deliver the source, signed APK location, tested behaviour, remaining limitations and how to switch back. Do not publish the learner’s screenshots, tasks, connection details or credentials with a teaching example.
